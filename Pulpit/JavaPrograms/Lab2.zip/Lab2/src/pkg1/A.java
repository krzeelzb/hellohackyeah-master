package pkg1;

import java.io.BufferedReader;
import java.io.*;

public class A {
    int number;
    //package  String name;

    public A(int number,String name){
        this.number=number;
        //this.name=name;
    }


    public void callDecrement(){
        number-=1;
    }

    public void callChangeName(){
        String text = null;
        InputStreamReader rd = new InputStreamReader(System.in);
        BufferedReader bfr = new BufferedReader(rd);

        //text = bfr.readLine();


    }

    public void callIncrement(){
        number+=1;
    }
    private void increment(){}
    protected void decrement(){}
   // package void changeName(){}
}
