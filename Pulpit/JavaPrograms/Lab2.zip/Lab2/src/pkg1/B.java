package pkg1;



public class B extends A {
    protected void decrement(){
        number-=2;
    }
    //package void changeName(){}
    private void increment(){
        number+=2;
    }
   // public B();
}
