package pkg2;

public class C {
    //package void changeName(){}
}
