package matrix;

public class MatrixProgram {
    public static void main(String[] argv) {
       // Matrix matrix=new Matrix(0,0);
       // matrix.add(new Matrix(3,4));




    }
}
